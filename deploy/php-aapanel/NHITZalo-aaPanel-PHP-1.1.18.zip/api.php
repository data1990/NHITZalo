<?php
declare(strict_types=1);
define('NHITZALO_INTERNAL', true);
require __DIR__ . '/bootstrap.php';

if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true)
    && (($_SERVER['HTTPS'] ?? '') !== 'on')) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo '{"error":"Cần truy cập qua HTTPS"}';
    exit;
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

function reply(array $data, int $status = 200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    exit;
}
function fail(string $message, int $status = 400): never { reply(['error' => $message], $status); }
function input(): array {
    $raw = file_get_contents('php://input');
    if (strlen($raw) > 2_000_000) fail('Dữ liệu quá lớn', 413);
    try { return json_decode($raw ?: '{}', true, 64, JSON_THROW_ON_ERROR); }
    catch (Throwable $e) { fail('JSON không hợp lệ'); }
}
function browser_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    session_name('nhitzalo_web');
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => !in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true), 'httponly' => true, 'samesite' => 'Strict']);
    session_start();
}
function current_user(): array {
    browser_session();
    $id = (int)($_SESSION['user_id'] ?? 0);
    if (!$id) fail('Chưa đăng nhập', 401);
    $stmt = db()->prepare('SELECT id,username,role,approved FROM users WHERE id = ?');
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    if (!$user || !$user['approved']) fail('Tài khoản chưa được duyệt', 403);
    return $user;
}
function require_csrf(): void {
    browser_session();
    $expected = $_SESSION['csrf'] ?? '';
    $actual = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!$expected || !hash_equals($expected, $actual)) fail('CSRF token không hợp lệ', 403);
}
function owned_account(int $id, int $owner): array {
    $stmt = db()->prepare('SELECT id,label,session_cipher,updated_at FROM zalo_accounts WHERE id=? AND owner_id=?');
    $stmt->execute([$id, $owner]);
    $account = $stmt->fetch();
    if (!$account) fail('Không tìm thấy tài khoản Zalo', 404);
    return $account;
}
function device_account(): array {
    $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/^Bearer ([a-f0-9]{64})$/i', $auth, $match)) fail('Thiếu mã thiết bị', 401);
    $hash = hash('sha256', hex2bin($match[1]));
    $stmt = db()->prepare('SELECT a.id,a.label,a.session_cipher,a.updated_at FROM device_tokens t JOIN zalo_accounts a ON a.id=t.account_id JOIN users u ON u.id=a.owner_id WHERE t.token_hash=? AND t.revoked_at IS NULL AND u.approved=1');
    $stmt->execute([$hash]);
    $account = $stmt->fetch();
    if (!$account) fail('Mã thiết bị không hợp lệ', 401);
    return $account;
}

try {
    $action = (string)($_GET['action'] ?? '');
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($action === 'health' && $method === 'GET') {
        try { db()->query('SELECT 1')->fetchColumn(); }
        catch (Throwable $e) { error_log('NHITZalo health: ' . $e->getMessage()); fail('PHP hoạt động nhưng không kết nối được MySQL hoặc cấu hình chưa hoàn tất', 503); }
        reply(['ok' => true, 'database' => true]);
    }
    if ($action === 'register' && $method === 'POST') {
        $data = input();
        $username = strtolower(trim((string)($data['username'] ?? '')));
        $password = (string)($data['password'] ?? '');
        if (!preg_match('/^[a-z0-9_.-]{3,40}$/', $username) || strlen($password) < 12) fail('Tên đăng nhập hoặc mật khẩu không hợp lệ');
        if ($username === 'admin') fail('Tên admin chỉ được tạo bằng lệnh quản trị trên máy chủ', 409);
        try {
            $stmt = db()->prepare('INSERT INTO users (username,password_hash,role,approved) VALUES (?,?,?,0)');
            $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT), 'user']);
        } catch (PDOException $e) { fail('Tên đăng nhập đã tồn tại', 409); }
        reply(['success' => true, 'message' => 'Đã đăng ký, chờ admin duyệt']);
    }
    if ($action === 'login' && $method === 'POST') {
        $data = input();
        $stmt = db()->prepare('SELECT id,username,password_hash,role,approved FROM users WHERE username=?');
        $stmt->execute([strtolower(trim((string)($data['username'] ?? '')))]);
        $user = $stmt->fetch();
        if (!$user || !password_verify((string)($data['password'] ?? ''), $user['password_hash'])) fail('Tên đăng nhập hoặc mật khẩu không đúng', 401);
        if (!$user['approved']) fail('Tài khoản đang chờ admin duyệt', 403);
        browser_session();
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
        reply(['user' => ['id' => $user['id'], 'username' => $user['username'], 'role' => $user['role']], 'csrf' => $_SESSION['csrf']]);
    }
    if ($action === 'desktop-login' && $method === 'POST') {
        $data = input();
        $username = strtolower(trim((string)($data['username'] ?? '')));
        $password = (string)($data['password'] ?? '');
        $stmt = db()->prepare('SELECT id,password_hash,approved FROM users WHERE username=?');
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($password, $user['password_hash'])) fail('Tên đăng nhập hoặc mật khẩu không đúng', 401);
        if (!$user['approved']) fail('Tài khoản đang chờ admin duyệt', 403);
        $stmt = db()->prepare('SELECT id,label,session_cipher IS NOT NULL AS has_session FROM zalo_accounts WHERE owner_id=? ORDER BY id DESC');
        $stmt->execute([(int)$user['id']]);
        $accounts = $stmt->fetchAll();
        if (!$accounts) {
            $stmt = db()->prepare('INSERT INTO zalo_accounts (owner_id,label) VALUES (?,?)');
            $stmt->execute([(int)$user['id'], 'Zalo của ' . $username]);
            $accounts = [['id' => (int)db()->lastInsertId(), 'label' => 'Zalo của ' . $username, 'has_session' => 0]];
        }
        $requested = (int)($data['account_id'] ?? 0);
        if (!$requested && count($accounts) > 1) reply(['accounts' => $accounts]);
        $selected = null;
        foreach ($accounts as $account) {
            if ((int)$account['id'] === ($requested ?: (int)$accounts[0]['id'])) { $selected = $account; break; }
        }
        if (!$selected) fail('Tài khoản Zalo không thuộc người dùng này', 403);
        $token = bin2hex(random_bytes(32));
        $stmt = db()->prepare('INSERT INTO device_tokens (account_id,token_hash) VALUES (?,?)');
        $stmt->execute([(int)$selected['id'], hash('sha256', hex2bin($token))]);
        reply(['account' => $selected, 'token' => $token]);
    }
    if ($action === 'me' && $method === 'GET') {
        $user = current_user();
        reply(['user' => $user, 'csrf' => $_SESSION['csrf'] ?? '']);
    }
    if ($action === 'logout' && $method === 'POST') {
        current_user(); require_csrf();
        $_SESSION = []; session_destroy(); reply(['success' => true]);
    }
    if ($action === 'pending-users' && $method === 'GET') {
        $user = current_user(); if ($user['role'] !== 'admin') fail('Chỉ admin được truy cập', 403);
        reply(['users' => db()->query("SELECT id,username,created_at FROM users WHERE approved=0 AND role='user' ORDER BY id")->fetchAll()]);
    }
    if ($action === 'approve-user' && $method === 'POST') {
        $user = current_user(); require_csrf(); if ($user['role'] !== 'admin') fail('Chỉ admin được duyệt', 403);
        $id = (int)(input()['id'] ?? 0);
        $stmt = db()->prepare("UPDATE users SET approved=1 WHERE id=? AND role='user' AND approved=0");
        $stmt->execute([$id]); if (!$stmt->rowCount()) fail('Không tìm thấy người dùng chờ duyệt', 404);
        reply(['success' => true]);
    }
    if ($action === 'accounts' && $method === 'GET') {
        $user = current_user();
        $stmt = db()->prepare('SELECT id,label,updated_at,session_cipher IS NOT NULL AS has_session FROM zalo_accounts WHERE owner_id=? ORDER BY id DESC');
        $stmt->execute([$user['id']]); reply(['accounts' => $stmt->fetchAll()]);
    }
    if ($action === 'create-account' && $method === 'POST') {
        $user = current_user(); require_csrf();
        $label = trim((string)(input()['label'] ?? ''));
        if ($label === '' || mb_strlen($label) > 100) fail('Tên tài khoản Zalo không hợp lệ');
        $stmt = db()->prepare('INSERT INTO zalo_accounts (owner_id,label) VALUES (?,?)');
        $stmt->execute([$user['id'], $label]); reply(['id' => db()->lastInsertId(), 'label' => $label]);
    }
    if ($action === 'device-code' && $method === 'POST') {
        $user = current_user(); require_csrf();
        $account = owned_account((int)(input()['account_id'] ?? 0), (int)$user['id']);
        $code = strtoupper(bin2hex(random_bytes(6)));
        $stmt = db()->prepare('INSERT INTO device_codes (account_id,code_hash,expires_at) VALUES (?,?,DATE_ADD(UTC_TIMESTAMP(), INTERVAL 10 MINUTE))');
        $stmt->execute([$account['id'], hash('sha256', $code)]);
        reply(['code' => $code, 'expires_in' => 600]);
    }
    if ($action === 'revoke-devices' && $method === 'POST') {
        $user = current_user(); require_csrf();
        $account = owned_account((int)(input()['account_id'] ?? 0), (int)$user['id']);
        $stmt = db()->prepare('UPDATE device_tokens SET revoked_at=UTC_TIMESTAMP() WHERE account_id=? AND revoked_at IS NULL');
        $stmt->execute([$account['id']]);
        reply(['success' => true]);
    }
    if ($action === 'device-pair' && $method === 'POST') {
        $code = strtoupper(trim((string)(input()['code'] ?? '')));
        if (!preg_match('/^[A-F0-9]{12}$/', $code)) fail('Mã ghép nối không hợp lệ');
        db()->beginTransaction();
        $stmt = db()->prepare('SELECT id,account_id FROM device_codes WHERE code_hash=? AND used_at IS NULL AND expires_at > UTC_TIMESTAMP() FOR UPDATE');
        $stmt->execute([hash('sha256', $code)]); $row = $stmt->fetch();
        if (!$row) { db()->rollBack(); fail('Mã hết hạn hoặc đã sử dụng', 401); }
        $token = bin2hex(random_bytes(32));
        $stmt = db()->prepare('INSERT INTO device_tokens (account_id,token_hash) VALUES (?,?)');
        $stmt->execute([$row['account_id'], hash('sha256', hex2bin($token))]);
        $stmt = db()->prepare('UPDATE device_codes SET used_at=UTC_TIMESTAMP() WHERE id=?');
        $stmt->execute([$row['id']]); db()->commit();
        reply(['token' => $token]);
    }
    if ($action === 'device-status' && $method === 'GET') {
        $account = device_account(); reply(['id' => $account['id'], 'label' => $account['label'], 'has_session' => $account['session_cipher'] !== null]);
    }
    if ($action === 'device-revoke' && $method === 'POST') {
        device_account();
        preg_match('/^Bearer ([a-f0-9]{64})$/i', $_SERVER['HTTP_AUTHORIZATION'] ?? '', $match);
        $stmt = db()->prepare('UPDATE device_tokens SET revoked_at=UTC_TIMESTAMP() WHERE token_hash=? AND revoked_at IS NULL');
        $stmt->execute([hash('sha256', hex2bin($match[1]))]);
        reply(['success' => true]);
    }
    if ($action === 'device-session') {
        $account = device_account();
        if ($method === 'GET') reply(['session' => $account['session_cipher'] ? decrypt_session($account['session_cipher'], (int)$account['id']) : null]);
        if ($method === 'PUT') {
            $session = input()['session'] ?? null;
            if (!is_array($session) || !is_string($session['imei'] ?? null) || !is_array($session['cookie'] ?? null)) fail('Phiên Zalo không hợp lệ');
            $uid = trim((string)($session['userInfo']['userId'] ?? ''));
            if ($uid !== '' && !preg_match('/^[0-9]{1,40}$/', $uid)) fail('ID Zalo không hợp lệ');
            $cipher = encrypt_session($session, (int)$account['id']);
            $uidValue = $uid === '' ? null : $uid;
            $stmt = db()->prepare('UPDATE zalo_accounts SET session_cipher=?,zalo_uid=COALESCE(zalo_uid, ?),updated_at=UTC_TIMESTAMP() WHERE id=? AND (zalo_uid IS NULL OR zalo_uid=?)');
            $stmt->execute([$cipher, $uidValue, $account['id'], $uidValue]);
            if (!$stmt->rowCount()) fail('Phiên thuộc tài khoản Zalo khác', 409);
            reply(['success' => true]);
        }
        if ($method === 'DELETE') {
            $stmt = db()->prepare('UPDATE zalo_accounts SET session_cipher=NULL,updated_at=UTC_TIMESTAMP() WHERE id=?');
            $stmt->execute([$account['id']]); reply(['success' => true]);
        }
    }
    fail('API không tồn tại', 404);
} catch (Throwable $e) {
    error_log('NHITZalo PHP: ' . $e->getMessage());
    fail('Lỗi máy chủ; xem PHP error log', 500);
}
